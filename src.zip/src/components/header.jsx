export default function Header() {
    return (
        <>
            <h1 className='mb-20 text-blue-950'>Игрвоая Консоль Nintendo Switch</h1>
        </>
    )
}